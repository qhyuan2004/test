#!/bin/bash

LD_LIBRARY_PATH=/usr/lib:/usr/lib64:./lib
export LD_LIBRARY_PATH

./bin/eatondevicesdktutorial

















